

#include <linux/kernel.h>
#include <linux/module.h>
#include <linux/init.h>
#include <linux/device.h>
#include <linux/i2c.h>

#include <linux/gpio.h>
#include <linux/delay.h>
#include <../arch/arm/mach-msm/LGE_Target/gpio_lgelu2300.h>


#include <linux/broadcast/broadcast_lg2102.h>
#include <linux/broadcast/broadcast_tdmb.h>

/************************************************************************/
/* LINUX Driver Setting                                                 */
/************************************************************************/
struct TDMB_LG2102_CTRL
{
	struct i2c_client*		pClient;
//	struct i2c_device_id*	pId;
};

static struct TDMB_LG2102_CTRL TdmbCtrlInfo;

struct i2c_client* INC_GET_I2C_DRIVER(void)
{
	return TdmbCtrlInfo.pClient;
}

void LGD_RW_TEST(void);

int tdmb_lg102_mdelay(int32 ms)
{
	mdelay(ms);

	return TRUE;
}

int tdmb_lg2102_power_on(void)
{
	gpio_tlmm_config( GPIO_CFG(DMB_EN, 0, GPIO_OUTPUT, GPIO_PULL_UP, GPIO_2MA), GPIO_ENABLE ) ;
	gpio_configure( DMB_EN, GPIOF_DRIVE_OUTPUT);

	gpio_tlmm_config( GPIO_CFG(DMB_RESET_N, 0, GPIO_OUTPUT, GPIO_PULL_UP, GPIO_2MA), GPIO_ENABLE ) ;
	gpio_configure( DMB_RESET_N, GPIOF_DRIVE_OUTPUT);

	udelay(500);
	
	gpio_set_value(DMB_EN, 1);
	gpio_set_value(DMB_RESET_N, 0);
	udelay(500);
	
	gpio_set_value(DMB_RESET_N, 1);

	return TRUE;
}

int tdmb_lg2102_power_off(void)
{

	gpio_set_value(DMB_EN, 0);
	gpio_set_value(DMB_RESET_N, 0);
	return TRUE;
}
 static int tdmb_lg2102_i2c_write(uint8* txdata, int length)
{
	uint16 addr, data;
	struct i2c_msg msg = 
	{	
		TdmbCtrlInfo.pClient->addr,
		0,
		length,
		txdata 
	};

	addr = txdata[0]<<8|txdata[1];
	data = txdata[2]<<8|txdata[3];

	if (i2c_transfer( TdmbCtrlInfo.pClient->adapter, &msg, 1) < 0) 
	{
		printk("tdmb lg2102 i2c write failed\n");
		return FALSE;
	}

	//printk("tdmb lg2102 i2c write addr = %x data = %x!! \n",addr, data);
	
	return TRUE;
}
 
int tdmb_lg2102_i2c_write_burst(uint16 waddr, uint8* wdata, int length)
{
 	uint8 *buf;
	int	wlen;

	int rc;

	wlen = length + 2;

	buf = (uint8*)kmalloc( wlen, GFP_KERNEL);

	if((buf == NULL) || ( length <= 0 ))
	{
		printk("tdmb_lg2102_i2c_write_burst buf alloc failed\n");
		return FALSE;
	}

	buf[0] = (waddr>>8)&0xFF;
	buf[1] = (waddr&0xFF);

	memcpy(&buf[2], wdata, length);
 
	rc = tdmb_lg2102_i2c_write(buf, wlen);

	kfree(buf);
		
	return rc;
}

static int tdmb_lg2102_i2c_read( uint16 raddr,	uint8 *rxdata, int length)
{
	uint8	r_addr[2] = {raddr>>8, raddr&0xff};
	uint16	addr, data;
	//uint8	acBuff[384];
	
	struct i2c_msg msgs[] = 
	{
		{
			.addr   = TdmbCtrlInfo.pClient->addr,
			.flags = 0,
			.len   = 2,
			.buf   = &r_addr[0],
		},
		{
			.addr   = TdmbCtrlInfo.pClient->addr,
			.flags = I2C_M_RD,
			.len   = length,
			.buf   = rxdata,
		},
	};
	
	//memset(acBuff, 0, sizeof(acBuff));

	if (i2c_transfer(TdmbCtrlInfo.pClient->adapter, msgs, 2) < 0) 
	{
		printk("tdmb_lg2102_i2c_read failed!\n");
		return FALSE;
	}
	
	//memcpy(rxdata,acBuff, length);

	addr = raddr;
	data = (uint16)rxdata[0] << 8 | (uint16)rxdata[1];
	
	printk("tdmb lg2102 i2c read addr = %x data = %x!! \n",addr, data);
	
	return TRUE;
}

int tdmb_lg2102_i2c_read_burst(uint16 raddr, uint8* rdata, int length)
{
	int rc;
 
	rc = tdmb_lg2102_i2c_read(raddr, rdata, length);

	return rc;

}


int tdmb_lg2102_i2c_write16(unsigned short reg, unsigned short val)
{
	unsigned int err;
	unsigned char buf[4] = { reg>>8, reg&0xff, val>>8, val&0xff };
	struct i2c_msg	msg = 
	{	
		TdmbCtrlInfo.pClient->addr,
		0,
		4,
		buf 
	};
	
	if ((err = i2c_transfer( TdmbCtrlInfo.pClient->adapter, &msg, 1)) < 0) 
	{
		dev_err(&TdmbCtrlInfo.pClient->dev, "i2c write error\n");
		err = FALSE;
	}
	else
	{
		printk(KERN_INFO "tdmb : i2c write ok:addr = %x data = %x\n", reg, val);
		err = TRUE;
	}

	return err;
}


int tdmb_lg2102_i2c_read16(uint16 reg, uint16 *ret)
{

	uint32 err;
	uint8 w_buf[2] = {reg>>8, reg&0xff};	
	uint8 r_buf[2] = {0,0};

	struct i2c_msg msgs[2] = 
	{
		{ TdmbCtrlInfo.pClient->addr, 0, 2, &w_buf[0] },
		{ TdmbCtrlInfo.pClient->addr, I2C_M_RD, 2, &r_buf[0]}
	};

	if ((err = i2c_transfer(TdmbCtrlInfo.pClient->adapter, msgs, 2)) < 0) 
	{
		dev_err(&TdmbCtrlInfo.pClient->dev, "i2c read error\n");
		err = FALSE;
	}
	else
	{
		printk( "tdmb addr = %x : i2c read ok: data[0] = %x data[1] = %x \n", TdmbCtrlInfo.pClient->addr, r_buf[0], r_buf[1]);
		*ret = r_buf[0]<<8 | r_buf[1];
		printk( "tdmb : i2c read ok: data = %x\n", *ret);
		err = TRUE;
	}

	return err;
}


void LGD_RW_TEST(void)
{
	unsigned short i = 0;
	unsigned short w_val = 0;
	unsigned short r_val = 0;
	unsigned short err_cnt = 0;

	err_cnt = 0;
	for(i=1;i<11;i++)
	{
		w_val = (i%0xFF);
		tdmb_lg2102_i2c_write16( 0x0a00+ 0x05, w_val);
		tdmb_lg2102_i2c_read16(0x0a00+ 0x05, &r_val );
		if(r_val != w_val)
		{
			err_cnt++;
			printk("w_val:%x, r_val:%x\n", w_val,r_val);
		}
	}
}



static int tdmb_lg2102_i2c_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	int nRet;

	memset(&TdmbCtrlInfo, 0x00, sizeof(struct TDMB_LG2102_CTRL));

	if(!i2c_check_functionality(client->adapter, I2C_FUNC_I2C)) {
		printk(KERN_ERR "tdmb_lg2102_i2c_probe: need I2C_FUNC_I2C\n");
		nRet = -ENODEV;
		return nRet;
	}

	TdmbCtrlInfo.pClient 	= client;
	//TdmbCtrlInfo.pId 		= id;
	
	i2c_set_clientdata(client, (void*)&TdmbCtrlInfo);

	printk("broadcast_tdmb_lg2102_i2c_probe start \n");
	
	return TRUE;
}
#if 0
static const struct i2c_device_id tdmb_lg2102_i2c_id[] = {
	{ "lg2102", 0},
	{ },
};

static struct i2c_driver tdmb_lg2102_i2c_driver = {
	.id_table = tdmb_lg2102_i2c_id,
	.probe  = tdmb_lg2102_i2c_probe,
	.driver = {
		.name = "lg2102",
	},
};
#endif
static int broadcast_tdmb_lg2102_probe(struct i2c_client *client, const struct i2c_device_id *id)
{
	int rc;

	rc = broadcast_tdmb_drv_start();

	printk("broadcast_tdmb_lg2102_probe start %d\n", rc);
#if 0
	rc = i2c_add_driver(&tdmb_lg2102_i2c_driver);
	if (rc < 0)
	{
	  printk("i2c_add_driver fail!! \n");
	  rc = -1;
	}
#endif
	tdmb_lg2102_i2c_probe(client, id);
    printk("broadcast_tdmb_lg2102_probe start \n");

	return rc;

}

static struct i2c_device_id tdmb_lg2102_idtable[] = {
	{ "tdmb_lg2102", 0 },
};


static struct i2c_driver broadcast_tdmb_driver = {
	.probe = broadcast_tdmb_lg2102_probe,
	.id_table = tdmb_lg2102_idtable,
	.driver = {
		.name = "tdmb_lg2102",
		.owner = THIS_MODULE,
	},
};

int __devinit broadcast_tdmb_drv_init(void)
{
	//memset(&TdmbCtrlInfo, 0, sizeof(TDMB_LG2102_CTRL));
	return i2c_add_driver(&broadcast_tdmb_driver);
}

static void __exit broadcast_tdmb_drv_exit(void)
{
	i2c_del_driver(&broadcast_tdmb_driver);
}

module_init(broadcast_tdmb_drv_init);
module_exit(broadcast_tdmb_drv_exit);
MODULE_DESCRIPTION("broadcast_tdmb_drv_init");
MODULE_LICENSE("INC");

